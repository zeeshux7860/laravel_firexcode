<?php

return [
    "myToken" => "appToken"
];